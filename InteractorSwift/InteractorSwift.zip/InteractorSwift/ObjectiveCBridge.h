//
//  ObjectiveCBridge.h
//  InteractorSwift

#ifndef ObjectiveCBridge_h
#define ObjectiveCBridge_h

#import <Interactor_static/Interactor.h>

#endif /* ObjectiveCBridge_h */

